# X-MIKZ Android WebView App

Aplikasi UI original dengan login demo (username/password bebas), dashboard, visual simulator, terminal log, efek glitch, dan settings. Seluruh aksi hanya simulasi lokal dan tidak punya izin internet.

## Build APK
1. Ekstrak ZIP.
2. Buka folder `X-MIKZ-App` lewat Android Studio.
3. Tunggu Gradle Sync. Instal Android SDK Platform 35 bila diminta.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

Login: isi username apa saja dan password apa saja. Username ditampilkan pada dashboard. Ini bukan autentikasi sungguhan; jangan pakai kata sandi pribadi.

Tidak termasuk malware, pengiriman pesan, akses akun, atau serangan ke aplikasi/perangkat lain.
